/**
 * Configuración centralizada de todas las series
 * Este archivo es la fuente de verdad para los datos de las series
 * La BD se sincroniza desde aquí
 */

/**
 * Interfaz para la configuración de una serie
 */
export interface SeriesConfig {
  id: number;
  name: string;
  slug: string;
  description: string;
  price: number;
  images: string[];
  colors: string[];
  sizes: Array<{
    size: string;
    type: 'standard' | 'king';
    available: boolean;
  }>;
  isActive: boolean;
  releaseDate: string; // ISO format
  endDate?: string; // ISO format
  seo: {
    title: string;
    description: string;
    keywords: string;
  };
}

/**
 * Array con todas las series configuradas
 */
export const seriesData: SeriesConfig[] = [
  {
    id: 0,
    name: 'SERIE 0',
    slug: 'serie-0',
    description: 'Serie piloto DCIEN. Edición de prueba limitada.',
    price: 40.00,
    images: [
      '/images/series/serie-0/main.jpg',
      '/images/series/serie-0/detail-1.jpg',
      '/images/series/serie-0/detail-2.jpg',
    ],
    colors: ['Negro'],
    sizes: [
      { size: 'S', type: 'standard', available: true },
      { size: 'M', type: 'standard', available: true },
      { size: 'L', type: 'standard', available: true },
      { size: 'XL', type: 'standard', available: true },
      { size: 'XXL', type: 'standard', available: true },
    ],
    isActive: true,
    releaseDate: '2026-02-15T00:00:00Z',
    seo: {
      title: 'SERIE 0 | DCIEN',
      description: 'Serie piloto DCIEN. Solo 100 unidades. Edición de prueba.',
      keywords: 'serie 0, edición piloto, dcien, camiseta exclusiva',
    },
  },
  
  {
    id: 1,
    name: 'SERIE 01',
    slug: 'serie-01',
    description: 'Primera serie oficial DCIEN. El inicio de la exclusividad.',
    price: 50.00,
    images: [
      '/images/series/serie-01/main.jpg',
      '/images/series/serie-01/detail-1.jpg',
      '/images/series/serie-01/detail-2.jpg',
    ],
    colors: ['Negro', 'Blanco'],
    sizes: [
      { size: 'S', type: 'standard', available: true },
      { size: 'M', type: 'standard', available: true },
      { size: 'L', type: 'standard', available: true },
      { size: 'XL', type: 'standard', available: true },
      { size: 'XXL', type: 'standard', available: true },
    ],
    isActive: true,
    releaseDate: '2026-03-01T00:00:00Z',
    seo: {
      title: 'SERIE 01 | DCIEN',
      description: 'Primera serie oficial DCIEN. Solo 100 unidades numeradas.',
      keywords: 'serie 01, primera edición, dcien, camiseta limitada',
    },
  },
  {
    id: 2,
    name: 'SERIE 02',
    slug: 'serie-02',
    description: 'Primera serie oficial DCIEN. El inicio de la exclusividad.',
    price: 40.00,
    images: [
      '/images/series/serie-02/main.jpg',
      '/images/series/serie-02/detail-1.jpg',
      '/images/series/serie-02/detail-2.jpg',
    ],
    colors: ['Negro', 'Blanco'],
    sizes: [
      { size: 'S', type: 'standard', available: true },
      { size: 'M', type: 'standard', available: true },
      { size: 'L', type: 'standard', available: true },
      { size: 'XL', type: 'standard', available: true },
      { size: 'XXL', type: 'standard', available: true },
    ],
    isActive: true,
    releaseDate: '2026-03-01T00:00:00Z',
    seo: {
      title: 'SERIE 02 | DCIEN',
      description: 'Primera serie oficial DCIEN. Solo 100 unidades numeradas.',
      keywords: 'serie 01, primera edición, dcien, camiseta limitada',
    },
  },
];

/**
 * Obtener serie por slug
 */
export function getSeriesBySlug(slug: string): SeriesConfig | undefined {
  return seriesData.find(s => s.slug === slug);
}

/**
 * Obtener series activas
 */
export function getActiveSeries(): SeriesConfig[] {
  return seriesData.filter(s => s.isActive);
}

/**
 * Obtener todas las series
 */
export function getAllSeries(): SeriesConfig[] {
  return seriesData;
}
